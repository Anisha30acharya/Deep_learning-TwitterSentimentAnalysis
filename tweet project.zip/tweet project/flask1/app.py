from flask import Flask, render_template, request, jsonify
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences
import pickle

app = Flask(__name__)

# Load model and tokenizer
model = tf.keras.models.load_model("tweet_model.h5")
with open("tokenizer.pkl", "rb") as f:
    tokenizer = pickle.load(f)

max_len = 100

def encode_tweet(text):
    sequences = tokenizer.texts_to_sequences([text])
    padded = pad_sequences(sequences, maxlen=max_len)
    return padded

@app.route('/')
def home():
    return render_template('RNNhome.html')  # this is now your main landing page

@app.route('/analyze')
def analyze():
    return render_template('RNNindex.html')  # this is the tweet analyzer

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    tweet = data.get('tweet')
    if not tweet:
        return jsonify({'error': 'No tweet provided'})

    processed = encode_tweet(tweet)
    prediction = model.predict(processed)[0][0]

    sentiment = "Positive" if prediction > 0.5 else "Negative"
    confidence = f"{prediction*100:.2f}%" if prediction > 0.5 else f"{(1 - prediction)*100:.2f}%"

    return jsonify({'sentiment': sentiment, 'confidence': confidence})

# ✅ THIS PART IS VERY IMPORTANT
if __name__ == '__main__':
    app.run(debug=True)
